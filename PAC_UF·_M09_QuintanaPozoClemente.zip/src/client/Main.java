package client;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        //Creamos el cliente
        Client cliente = new Client();
        //se conecta el cliente
        cliente.startClient();
    }
}


// Apuntes, pdf y videtutorias Ilerna Programacion de servicios y procesos 2ºDAM
//https://www.programarya.com/Cursos-Avanzados/Java/Sockets